## mypackage 
This was created as my first learning example on how to create my own package

## How to build this locally 
'python setup.py sdist'

## how to install this package 
'pip install git+https://github.com/moloGSD/mypackage.git'

## how to upgrade the package 
'pip install --upgrade git+https://github.com/moloGSD/mypackage.git'

## How to use
' from mypackage import topn 