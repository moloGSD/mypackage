def topn(items, n):
    """
    Sorts a list of items in ascending order and returns the top n elements in descending order.

    Args:
        items (list): A list of comparable elements to be sorted.
        n (int): The number of top elements to return.

    Returns:
        list: A list containing the top n elements from the sorted list in descending order.

    Examples:
        >>> topn([5, 3, 8, 1, 9, 2, 7, 4, 6], 3)
        [9, 8, 7]
        >>> topn(['apple', 'banana', 'orange', 'grape'], 2)
        ['orange', 'grape']
    """
    for i in range(n):
        for j in range(len(items) - 1 - i):
            if items[j] > items[j + 1]:
                items[j], items[j + 1] = items[j + 1], items[j]
    topn = items[-n:]
    return topn[::-1]
